<?php get_header(); ?>
<!--Singular-->
<br>
<br>
<br>
<br>
<main class="page">
    <div class="wrapper">
        <div>
            <h1><?php the_title() ?></h1>
            <div><?php the_content() ?></div>
        </div>
    </div>
</main>
<br>
<br>
<br>
<br>
<!--/Singular-->
<?php get_footer(); ?>