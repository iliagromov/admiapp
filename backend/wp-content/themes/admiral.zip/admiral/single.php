<?php get_header(); ?>
<!-- single -->
<br>
<br>
<br>
<br>
<main class="page">
    <div class="wrapper">
    <div>
        <h1><?php the_title() ?></h1>
        <div><?php the_content() ?></div>
    </div>
    </div>
   
</main>
<br>
<br>
<br>
<br>
<!-- /single -->
<?php get_footer(); ?>
