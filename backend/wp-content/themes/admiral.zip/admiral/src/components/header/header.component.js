let header = 'header component works';
console.log(header);