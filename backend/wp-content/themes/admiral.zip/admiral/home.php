<?php get_header(); ?>
<!-- home -->
<main class="page mainPage">
</main>
<!-- /home -->
<?php get_footer(); ?>