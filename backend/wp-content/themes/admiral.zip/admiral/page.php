<?php get_header(); ?>
<!--page-->
<br>
<br>
<br>
<br>

<main class="page">
    <div class="wrapper">
        <div>
            <h1><?php the_title() ?></h1>
            <div><?php the_content() ?></div>
        </div>
    </div>

</main>
<br>
<br>
<br>
<br>
<!--/page-->
<?php get_footer(); ?>