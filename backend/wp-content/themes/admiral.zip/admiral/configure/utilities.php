<?php

// Utilities functions here